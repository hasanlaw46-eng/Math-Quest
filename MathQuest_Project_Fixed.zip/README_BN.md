# Math Quest Android Project

এটি Math Quest-এর Android WebView wrapper project। গেমের মূল HTML ফাইল `app/src/main/assets/index.html`-এ রাখা হয়েছে।

## ফোন দিয়ে APK তৈরি (GitHub Actions)

1. GitHub repository-তে এই ZIP-এর ভেতরের সব ফাইল ও ফোল্ডার upload করো। ZIP ফাইল নিজে upload করবে না।
2. ফাইলগুলো repository-র মূল (root) জায়গায় থাকবে। `app` ফোল্ডারটি অবশ্যই দেখা যেতে হবে।
3. সব ফাইল upload করে commit করো।
4. GitHub repository-র **Actions** tab খোলো।
5. `Build Math Quest APK` workflow বেছে **Run workflow** চাপো (push করলেও workflow চলবে)।
6. Build শেষ হলে run-এর নিচে **Artifacts** থেকে `Math-Quest-debug-APK` ডাউনলোড করো।
7. ZIP artifact extract করলে `app-debug.apk` পাবে। এটি নিজের ফোনে পরীক্ষা করার জন্য।

## গুরুত্বপূর্ণ
- এটি debug APK; Play Store-এ সরাসরি প্রকাশের জন্য নয়।
- Play Store-এর জন্য পরে release AAB, signing, store listing, privacy policy এবং Play Console-এর বর্তমান নিয়ম পূরণ করতে হবে।
- এই অ্যাপ offline; manifest-এ INTERNET permission নেই।
- WebView-তে JavaScript এবং DOM storage শুধু গেম চালানোর জন্য চালু; file/content access বন্ধ এবং external navigation আটকানো।
- গেমের score/progress local device-এর WebView storage-এ থাকে; uninstall/clear data করলে হারাতে পারে।
- Client-side score tamper-proof নয়। Online leaderboard বা account system এই project-এ নেই।
